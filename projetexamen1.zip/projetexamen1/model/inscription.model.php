<?php
function find_all_professeur():array{
    $professeurs=[
        ["id"=>1,"nom"=>"Wane","prenom"=>"Baila","grade"=>"Ingénieur","modules"=>["UML","Algo","Php"]],
        ["id"=>2,"nom"=>"Niang","prenom"=>"Aly","grade"=>"Ingénieur","modules"=>["Python","Algo","C"]]
    ];
    return $professeurs;
}

function find_all_classe_professeur():array{
    $classeProfesseurs=[
        ["id"=>1,"professeur_id"=>1,"classe_id"=>1],
        ["id"=>2,"professeur_id"=>1,"classe_id"=>2],
        ["id"=>3,"professeur_id"=>1,"classe_id"=>3],
        ["id"=>4,"professeur_id"=>2,"classe_id"=>4],
        ["id"=>5,"professeur_id"=>2,"classe_id"=>2]
    ];
    return $classeProfesseurs;
}

function find_all_demande():array{
    $demandes=[
        ["id"=>1,"inscription_id"=>1,"objet"=>"suspension","motif"=>"problème de paiement","statut"=>"annulé"],
        ["id"=>2,"inscription_id"=>3,"objet"=>"annulation","motif"=>"problème de santé","statut"=>"accepté"]
    ];
    return $demandes;
}

function find_all_classe():array{
    $classes=[
        ["id"=>1,"filiere"=>"GLRS","niveau"=>"L1"],
        ["id"=>2,"filiere"=>"GLRS","niveau"=>"L2"],
        ["id"=>3,"filiere"=>"GLRS","niveau"=>"L3"],
        ["id"=>4,"filiere"=>"MAE","niveau"=>"L1"],
        ["id"=>5,"filiere"=>"MAE","niveau"=>"L2"],
        ["id"=>6,"filiere"=>"MAE","niveau"=>"L3"]
    ];
    return $classes;
}

function find_all_etudiant():array{
    $etudiants=[
        ["id"=>1,"matricule"=>uniqid(),"nom"=>"Diop","prenom"=>"Adama"],
        ["id"=>2,"matricule"=>uniqid(),"nom"=>"Fall","prenom"=>"Ada"],
        ["id"=>3,"matricule"=>uniqid(),"nom"=>"Moussa","prenom"=>"Amadou"],
        ["id"=>4,"matricule"=>uniqid(),"nom"=>"Ali","prenom"=>"Abou"],
        ["id"=>5,"matricule"=>uniqid(),"nom"=>"Dieng","prenom"=>"Aly"]
    ];
    return $etudiants;
}
function find_all_incription():array{
    $inscriptions=[
        ["id"=>1,"etudiant_id"=>1,"classe_id"=>1,"annee"=>"2021-2022"],
        ["id"=>2,"etudiant_id"=>2,"classe_id"=>1,"annee"=>"2021-2022"],
        ["id"=>3,"etudiant_id"=>3,"classe_id"=>4,"annee"=>"2021-2022"],
        ["id"=>4,"etudiant_id"=>4,"classe_id"=>4,"annee"=>"2021-2022"],
        ["id"=>5,"etudiant_id"=>5,"classe_id"=>4,"annee"=>"2021-2022"],
        ["id"=>6,"etudiant_id"=>1,"classe_id"=>2,"annee"=>"2022-2023"],
        ["id"=>7,"etudiant_id"=>2,"classe_id"=>2,"annee"=>"2022-2023"],
        ["id"=>8,"etudiant_id"=>3,"classe_id"=>4,"annee"=>"2022-2023"],
        ["id"=>9,"etudiant_id"=>4,"classe_id"=>5,"annee"=>"2022-2023"],
        ["id"=>10,"etudiant_id"=>5,"classe_id"=>5,"annee"=>"2022-2023"]
    ];
    return $inscriptions;
}



function find_classes_by_niveau(string $niveau):array{
    $classesByNiveau=[];
    $classes=find_all_classe();
    foreach($classes as $classe){
        if($classe["niveau"]===$niveau){
            $classesByNiveau[]=$classe;
        }
    }
    return $classesByNiveau;
}

function find_classes_by_filiere(string $filiere):array{
    $classesByNiveau=[];
    $classes=find_all_classe();
    foreach($classes as $classe){
        if($classe["filiere"]===$filiere){
            $classesByNiveau[]=$classe;
        }
    }
    return $classesByNiveau;
}

function find_etudiant_by_id(int $id):array|null{
    $etudiants=find_all_etudiant();
    foreach($etudiants as $e){
        if($e["id"]===$id){
            return $e;
        }
    }
    return null;
}

function find_classe_by_id(int $id):array|null{
    $classes=find_all_classe();
    foreach($classes as $classe){
        if($classe["id"]===$id){
            return $classe;
        }
    }
    return null;
}

function find_all_incription_classe():array{
    $inscriptions=find_all_incription();
    $inscriptionClasse=[];
    foreach($inscriptions as $inscription){
        $etudiant=find_etudiant_by_id($inscription["etudiant_id"]);
        $classe=find_classe_by_id($inscription["classe_id"]);
        $inscriptionClasse[]=[
            "id"=>$inscription["id"],
            "nom_complet"=>$etudiant["nom"]." ".$etudiant["prenom"],
            "classe"=>$classe["niveau"]."".$classe["filiere"],
            "annee"=>$inscription["annee"]
        ];
    }
    return $inscriptionClasse;
}

function find_inscription_by_id(int $id):array|null{
    $inscriptions=find_all_incription_classe();
    foreach($inscriptions as $inscription){
        if($inscription["id"]===$id){
            return $inscription;
        }
    }
    return null;
}

function find_all_demande_etudiant():array{
    $demandes=find_all_demande();
    $demandeEtudiant=[];
    foreach($demandes as $demande){
        $inscription=find_inscription_by_id($demande["inscription_id"]);
        $demandeEtudiant[]=[
            "id"=>$demande["id"],
            "nom_complet"=>$inscription["nom_complet"],
            "classe"=>$inscription["classe"],
            "objet"=>$demande["objet"],
            "motif"=>$demande["motif"],
            "statut"=>$demande["statut"],
            "annee"=>$inscription["annee"]
        ];
    }
    return $demandeEtudiant;
}

function find_all_classe_by_professeur(int $id):array{
    $classeProfesseurs=find_all_classe_professeur();
    $classes=[];
    foreach($classeProfesseurs as $prof){
        if($prof["professeur_id"]===$id){
            $classe=find_classe_by_id($prof["classe_id"]);
            $classes[]=$classe["niveau"]."".$classe["filiere"];
        }
    }
    return $classes;
}

function find_all_professeur_classe():array{
    $profs=find_all_professeur();
    foreach($profs as $key=>$prof){
        $profs[$key]["classes"]=find_all_classe_by_professeur($prof["id"]);
    }
    // echo("<pre>");
    // var_dump($profs);
    // echo("</pre>");
    // die;
    return $profs;
}
?>