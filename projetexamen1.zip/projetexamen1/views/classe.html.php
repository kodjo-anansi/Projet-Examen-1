<?php
$classes=find_all_classe();
?>
<div class="conteneur">
    <div class="class">
        <table>
            <tr>
                <th>ID</th>
                <th>FILIERE</th>
                <th>NIVEAU</th>
                <th>LIBELLE</th>
            </tr>
            <?php foreach($classes as $value):?>
                <tr>
                    <td><?php echo($value["id"]) ?></td>
                    <td><?= $value["filiere"] ?></td>  <!-- syntaxe abrégé -->
                    <td><?= $value["niveau"] ?></td>
                    <td><?= $value["niveau"]."".$value["filiere"] ?></td>
                </tr>
            <?php endforeach ?>
        </table>
    </div>
</div>