<?php
$demandes=find_all_demande_etudiant();
?>
    <div class="conteneur">
        <div class="class">
            <table>
                <tr>
                    <th>ID</th>
                    <th>NOM ET PRENOM</th>
                    <th>CLASSE</th>
                    <th>OBJET</th>
                    <th>MOTIF</th>
                    <th>STATUT</th>
                    <th>ANNEE</th>
                </tr>
                <?php foreach($demandes as $demande):?>
                    <tr>
                        <td><?= $demande["id"] ?></td>
                        <td><?= $demande["nom_complet"] ?></td>  
                        <td><?= $demande["classe"] ?></td>
                        <td><?= $demande["objet"] ?></td>
                        <td><?= $demande["motif"] ?></td>
                        <td><?= $demande["statut"] ?></td>
                        <td><?= $demande["annee"] ?></td>
                    </tr>
                <?php endforeach ?>
            </table>
        </div>
    </div>