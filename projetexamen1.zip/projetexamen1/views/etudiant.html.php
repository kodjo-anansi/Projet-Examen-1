<?php
$etudiants=find_all_etudiant();
?>
    <div class="conteneur">
        <div class="class">
            <table>
                <tr>
                    <th>ID</th>
                    <th>MATRICULE</th>
                    <th>NOM</th>
                    <th>PRENOM</th>
                </tr>
                <?php foreach($etudiants as $value):?>
                    <tr>
                        <td><?php echo($value["id"]) ?></td>
                        <td><?= $value["matricule"] ?></td>  
                        <td><?= $value["nom"] ?></td>
                        <td><?= $value["prenom"] ?></td>
                    </tr>
                <?php endforeach ?>
            </table>
        </div>
    </div>