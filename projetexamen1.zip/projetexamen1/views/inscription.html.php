<?php
$inscriptions=find_all_incription_classe();
?>
    <div class="conteneur">
        <div class="class">
            <table>
                <tr>
                    <th>ID</th>
                    <th>NOM ET PRENOM</th>
                    <th>CLASSE</th>
                    <th>ANNEE</th>
                </tr>
                <?php foreach($inscriptions as $inscription):?>
                    <tr>
                        <td><?= $inscription["id"] ?></td>
                        <td><?= $inscription["nom_complet"] ?></td>  
                        <td><?= $inscription["classe"] ?></td>
                        <td><?= $inscription["annee"] ?></td>
                    </tr>
                <?php endforeach ?>
            </table>
        </div>
    </div>