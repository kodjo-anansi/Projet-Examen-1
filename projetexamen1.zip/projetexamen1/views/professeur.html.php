<?php
$professeurs=find_all_professeur_classe();
?>
    <div class="conteneur">
        <div class="class">
            <table>
                <tr>
                    <th>ID</th>
                    <th>NOM</th>
                    <th>PRENOM</th>
                    <th>GRADE</th>
                    <th>MODULES</th>
                    <th>CLASSES</th>
                </tr>
                <?php foreach($professeurs as $professeur):?>
                    <tr>
                        <td><?= $professeur["id"] ?></td>
                        <td><?= $professeur["nom"] ?></td>
                        <td><?= $professeur["prenom"] ?></td>
                        <td><?= $professeur["grade"] ?></td>
                        <td><?php echo(implode(", ",$professeur["modules"]))  ?></td>
                        <td><?php echo(implode(", ",$professeur["classes"]))  ?></td>
                    </tr>
                <?php endforeach ?>
            </table>
        </div>
    </div>